export interface Navigation {
    text: string;
    path: string;
    module: string;
    start?: string;
}

export default Navigation;
