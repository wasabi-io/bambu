const workspaceStyle = require('./index.scss');

export default workspaceStyle;
