export const mainContent: string;
export const isLink: string;
export const isFirstTabIsNotActive: string;
